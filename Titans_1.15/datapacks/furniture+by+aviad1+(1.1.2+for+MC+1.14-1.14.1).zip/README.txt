In order to use:

1. Go to the minecraft menu.
2. Click "options" and then "resource packs".
3. Click "open resource packs folder".
4. Copy the file "furniture resource pack by aviad1" into the folder that opened.
5. Enable the resource pack.

6. Click on "single player" and then on the world you want to use.
7. Click "edit" and then "open folder".
8. Go to the folder "datapacks" that is in the folder that opened.
9. Copy the file "furniture data pack by aviad1" to that folder.

10. Run the world, and have fun!